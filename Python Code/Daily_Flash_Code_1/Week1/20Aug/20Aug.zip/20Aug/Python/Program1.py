l1=[('Dhoni','Right'),('Raina','Left'),('Jadeja','Left'),('Rohit','Right')]
d1=dict(l1)
print(d1)
