movies={'The Last Samurai':'Tom Cruise','Justice League':'Cavil,Gadat','MI':'Tom Cruise'}
l=list()
for i in movies:
    if(movies[i]=='Tom Cruise'):
        l.append(i)
print(l)

