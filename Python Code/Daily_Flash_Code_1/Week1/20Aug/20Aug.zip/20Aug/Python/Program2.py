def create(*key):
    d1=dict(key)
    print(d1)
create((10,'Sachin'),(7,'Dhoni'),(18,'Kohli'),(17,'ABD'))
