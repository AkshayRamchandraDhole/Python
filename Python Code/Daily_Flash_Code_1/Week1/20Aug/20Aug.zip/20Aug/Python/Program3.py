dc={'Germany':'Berlin','Italy':'Venice','France':'Versailes','Canada':'Quebec City'}
for i in dc:
    print(i)
    print(dc[i])
