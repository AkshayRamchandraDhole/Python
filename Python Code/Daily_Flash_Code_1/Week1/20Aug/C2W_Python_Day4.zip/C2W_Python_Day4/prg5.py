movies = {"The Last Samurai" : "Tom Cruise, Ken", "Justice League" : "Cavil, Gadot", "MI" : "Tom Cruise"}

tom_starrer = list()

for i in movies :

    if "Tom Cruise" not in movies[i] :
        tom_starrer.append(i)

print(tom_starrer)
