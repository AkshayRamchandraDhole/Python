batsman = [('Dhoni', 'Right'), ('Raina', 'Left'), ('Jadeja', 'Left'), ('Rohit', 'Right')]
print(dict(batsman))
