dc = {'Germany' : 'Berlin', 'Italy' : 'Venice', 'France' : 'Versailles', 'Canada' : 'Quebec City'}

flag = 0

for i in dc :

    if flag == 0 :
        print(i)
        flag = 1

    else :
        print(dc[i])
        flag = 0
