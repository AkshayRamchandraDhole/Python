def create(**list):
    print(dict(list))
    
create(Germany = 'Berlin', France = 'Paris', England = 'London')
