movie=input("Enter Your Favorite movie:").split(",")
l1=tuple(movie)
print(l1)
