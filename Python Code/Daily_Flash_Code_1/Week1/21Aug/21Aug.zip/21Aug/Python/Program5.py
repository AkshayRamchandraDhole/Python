europe=("Germany","Spain","France","Italy","Switzerland","Luxembourg","Bosnia")
print(europe[::-1])
