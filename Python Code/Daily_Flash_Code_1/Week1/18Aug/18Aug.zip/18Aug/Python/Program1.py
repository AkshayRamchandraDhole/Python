list1=["Aunt(Paternal)","Grandpa","GrandMa","Uncle","Aunt(Paternal)","Uncle(Maternal)","Uncle(Maternal)"]
print(list1)
s1=set(list1)
t1=tuple(s1)
print(t1)
