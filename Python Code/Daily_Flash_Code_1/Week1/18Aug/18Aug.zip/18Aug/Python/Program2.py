l1=[1,3,5,7,9]
arr1=[i*i for i in l1]
print(arr1)
