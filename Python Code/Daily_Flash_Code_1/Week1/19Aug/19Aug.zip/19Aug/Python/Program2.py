nm=input("Enter First Name:")
ls=input("Enter Last Name:")
s1=set()
for i in nm:
    s1.add(i)
for i in ls:
    s1.add(i)
for i in s1:
    print(i,end=" ")
print()
    

    
        



