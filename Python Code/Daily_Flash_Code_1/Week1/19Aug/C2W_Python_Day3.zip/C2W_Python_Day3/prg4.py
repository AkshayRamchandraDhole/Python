infinity_war_cast = ("Ruffalo", "Holland", "Brolin", "RDJ", "Evans", "Cumberbatch", "Hemsworth")
deadpool_2_cast = ["Brolin", "Reynolds", "Karan Soni", "Matt Damon"]

print(set(infinity_war_cast).difference(deadpool_2_cast))
