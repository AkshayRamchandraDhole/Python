marvel = ['Robert Downey Jr', 'Chris Hemsworth', 'Scarlett Johansson', 'Ryan Reynolds']
dc = ['Gal Gadot', 'Henry Cavil', 'Ezra Miller', 'Ryan Reynolds']

print(set(marvel).symmetric_difference(dc))
