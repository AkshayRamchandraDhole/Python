import sys
print("Maximum Depth of the python interpreter stack : ",sys.getrecursionlimit())

