def fun(arr) :

    for i in arr:
        print(i)

    fun(arr)

from array import *
a = array('i', [1, 2, 3, 4])
fun(a)
