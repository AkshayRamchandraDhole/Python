from array import *
arr = array('i', [0, 0, 2, 2, 4, 4, 6, 6, 8, 8, 10, 10])
print(array('i', set(arr)))
