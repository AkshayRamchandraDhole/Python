import sys
print(sys.modules,end="\n")
