import random
st=input("Enter String:")
l=list()
l.append(st)
for i in range(1,len(st)):
    l.append(st[i:])
    l.append(st[::-i])
print(l)


