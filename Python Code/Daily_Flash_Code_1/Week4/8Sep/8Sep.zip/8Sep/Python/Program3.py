l=[18,7,45,7,10,17,10]
print(l)
print(list(set(l)))
