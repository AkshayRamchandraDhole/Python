l1=["Black Panther","Civil War","Endgame","Infinity War"]
d1=dict.fromkeys(x for x in l1)
for i in d1:    d1[i]="Marval"     
print(d1)

