import this
print()
