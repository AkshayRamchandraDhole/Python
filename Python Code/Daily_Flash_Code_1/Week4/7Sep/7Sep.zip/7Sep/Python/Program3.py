d1=dict.fromkeys(x for x in range(1,10) if x % 2 !=0 )
print(d1)
