import array
lEven=[0,2,4,6,8,10]
a=[x for x in lEven]
arr=array.array('i',a)
print(arr)

