import array as arr
arr1=arr.array('i',[10 for i in range(5)])
print(arr1)
