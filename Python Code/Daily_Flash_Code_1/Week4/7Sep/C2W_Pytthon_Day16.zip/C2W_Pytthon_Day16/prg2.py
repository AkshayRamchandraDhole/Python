from array import array
arry = array('d', [1, 3, 5, 7, 9])
print(arry.typecode, arry.itemsize)
