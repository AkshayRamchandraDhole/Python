dc = dict.fromkeys([1, 3, 5, 7, 9])
print(dc)
