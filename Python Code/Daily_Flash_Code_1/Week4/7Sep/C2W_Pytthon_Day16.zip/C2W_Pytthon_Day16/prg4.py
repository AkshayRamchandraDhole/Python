from numpy import array
movies = array(['Black Panther', 'Civil War', 'Endgame', 'Infinity War'])
print(dict.fromkeys(movies, 'Marvel'))
