import random
li=["Chopsy","Fritters","Fries","Scrambled Eggs","Chiken65"]
l=len(li)-1
n=random.randint(0,l)
print(li[n])
