def prime(n):
    n = int(n)

    for i in range(2, int(n / 2 + 1)) :
        if n % i == 0:
            return False

    return True

n = input("Enter number\n")

print('Emirp') if prime(n) and prime(n[: : -1]) else print('Not Emirp')
