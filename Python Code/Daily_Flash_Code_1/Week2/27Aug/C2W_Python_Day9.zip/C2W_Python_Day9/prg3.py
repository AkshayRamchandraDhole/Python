from random import randrange
print(randrange(int(input("Enter starting value\n")), int(input("Enter ending value\n"))))
