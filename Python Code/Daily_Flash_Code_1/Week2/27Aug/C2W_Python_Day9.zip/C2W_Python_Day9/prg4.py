from random import choice

starters = ['Chopsy', 'Fritters', 'Fries', 'Scrambled Eggs', 'Chicken 65']
print(choice(starters))
