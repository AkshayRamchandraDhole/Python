val1 = 2
val2 = 1
sum = 0

for i in range(7):
    print(val1, end = " ")
    sum = val1 + val2
    val1 = val2
    val2 = sum
    
print()
