n = input("Enter number\n")

pow = len(n)
sum = 0

for i in n :
    sum += int(i) ** pow

print('Narcisstic') if str(sum) == n else print('Not Narcisstic')
