from os import system

system('ps -e')
