from os import system
system('figlet Core2Web -f bubble')
