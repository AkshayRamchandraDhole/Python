from os import system
system('python3 /home/abhijeet/Coding/hello.py')

'''
It is totally possible to do everything through a python program, what can be done through a terminal.
For that we need to use 'system' in python, to execute shell commands.

Now,
While giving any program to run to python interpreter(python3).
We can give full path of program or relative path

Full path is /home/user/Coding/hello.py 
'''
