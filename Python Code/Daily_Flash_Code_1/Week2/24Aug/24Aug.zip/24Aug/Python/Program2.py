Str1=input("Enter String1:")
Str2=input("Enter String2:")
len1=len(Str1)
len2=len(Str2)
if(Str1==Str2):
    print("String Equal..")
elif(len2 > len1):
    print("Str2 is greater...")
elif(len2 < len1):
    print("Str1 is greater...")


