def mood():
    md=input("Enter Your Mood like(Motivated,Bored,Joyful,Cheerful):")
    if(md=="Motivated"):
        print("Watch movie like THE SOCIAL NETWORK")
    elif(md=="Bored"):
        print("Watch movie like SCI-FI")
    elif(md=="Joyful"):
        print("Watch movie like BLOCKERS")
    elif(md=="Cheerful"):
        print("Watch movie like THE SOUND OF MUSIC")
mood()
