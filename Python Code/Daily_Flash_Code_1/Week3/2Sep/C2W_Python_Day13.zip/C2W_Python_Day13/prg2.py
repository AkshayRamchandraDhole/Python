def isPalindrome(n):

    if str(n) == str(n)[: : -1] :
        return True

for i in range(88, 122) :

    if isPalindrome(i):
        print(i, end = " ")
print()
