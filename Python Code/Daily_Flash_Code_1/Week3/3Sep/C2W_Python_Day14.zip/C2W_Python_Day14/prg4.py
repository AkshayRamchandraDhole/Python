def operate(n):
    print(-(n+1))

operate(int(input("Enter a number\n")))
