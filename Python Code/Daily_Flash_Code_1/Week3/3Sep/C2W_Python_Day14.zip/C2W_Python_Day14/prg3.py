def showSnacks() :

    '''
    "This function shows
     the snacks from India"
    '''


    print("The snacks from India are Dabeli, Jalebi, Pohe, Pani Puri")

print(showSnacks.__doc__)
