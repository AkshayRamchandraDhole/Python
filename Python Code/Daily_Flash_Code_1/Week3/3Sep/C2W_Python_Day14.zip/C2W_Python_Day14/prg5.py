from os import system

def shutdown():
    system('shutdown')

shutdown()
