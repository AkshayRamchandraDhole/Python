st1=input("Enter String1:")
st2=input("Enter String2:")
st1=st1+st2
print("First String after concat:",st1)

