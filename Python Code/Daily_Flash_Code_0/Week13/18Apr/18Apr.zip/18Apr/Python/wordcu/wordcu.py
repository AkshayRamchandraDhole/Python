st=input("Enter String:")
a=0
l=st.split(" ")
for i in range(len(l)):
    a+=1
print("The entered string contain",a,"words")
