st=input("Enter String:")
print("Revsered String is:",st[::-1])
