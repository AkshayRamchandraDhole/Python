st=input("Enter String:")
print("String After replacement:")
print(st.swapcase())
