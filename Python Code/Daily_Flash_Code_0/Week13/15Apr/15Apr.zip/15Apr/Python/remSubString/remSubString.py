st=input("Enter String:")
su=input("Enter substring to delete:")
res=st.split(' ',1)[1]
print("String after deletion:",str(res))
