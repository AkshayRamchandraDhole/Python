n=int(input("Enter Number:"))
print("Cube Root is:",n**(1/3))
