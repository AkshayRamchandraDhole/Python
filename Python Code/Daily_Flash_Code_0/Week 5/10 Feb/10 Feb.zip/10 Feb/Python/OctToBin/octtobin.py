n=int(input("Enter Octal Number:-"))
print("Binary is:",bin(n))
