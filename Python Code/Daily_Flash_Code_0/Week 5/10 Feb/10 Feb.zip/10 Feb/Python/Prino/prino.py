n=0
while(n>=0):
	num=int(input("Enter Number:"))
	if(num>0):
		print(num)
	else:
		break

