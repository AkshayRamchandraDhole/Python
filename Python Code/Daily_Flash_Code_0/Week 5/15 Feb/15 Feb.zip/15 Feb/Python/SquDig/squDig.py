n=int(input("Enter Number:"))
while n > 0 :
	n1= n % 10
	a=n1*n1
	print(a,end=' ')
	n=n // 10
print()
