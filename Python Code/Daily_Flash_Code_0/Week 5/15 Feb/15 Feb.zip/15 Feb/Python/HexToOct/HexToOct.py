hexdec = input("Enter a number in Hexadecimal Format: ")
dec = int(hexdec, 16)
print(hexdec,"in Octal =",oct(dec));
