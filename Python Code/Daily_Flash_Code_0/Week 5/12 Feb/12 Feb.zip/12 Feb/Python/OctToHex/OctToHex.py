n=input("Enter Number:")
a=str(int(n,8))
h=int(a)
print("Hexadecimal Number:",hex(h))
