r=1
n=int(input("Enter Range:"))
while n > 0 :
	if(n % 2 !=0):
		print(n,end=' ')
	n=n-1
print()
