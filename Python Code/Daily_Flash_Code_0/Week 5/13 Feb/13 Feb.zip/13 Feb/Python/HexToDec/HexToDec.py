n=input("Enter Number in Hexadecimal:")
dec=int(n,16)
print("Decimal is:",str(dec))
