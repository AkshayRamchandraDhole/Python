n=input("Enter Hexa Number:")
res=bin(int(n,16))
print("Binary is:",str(res))
