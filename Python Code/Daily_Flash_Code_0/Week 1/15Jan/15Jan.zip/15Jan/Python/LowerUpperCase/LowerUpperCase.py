ch=input("Enter A Character")

if(ch >= 'a' and  ch <= 'z'):
	print(" Letter "+ch+" is in lowercase")
else :
	print("Letter "+ch+" is in UpperCase")
