a=int(input("Enter 1st Angle of Traingle:-"))
b=int(input("Enter 2nd Angle of Triangle:-"))
c=int(input("Enter 3rd Angle of Triangle:-"))

d=a+b+c

if(d==180):
	print("Valid Triangle")
else:
	print("Invalid Triangle")

