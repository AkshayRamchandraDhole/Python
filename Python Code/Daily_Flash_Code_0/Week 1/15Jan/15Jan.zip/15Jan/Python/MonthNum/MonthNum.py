a=int(input("Enter A Month Number:-"))

if(a==1):
	print("Jan")
elif(a==2):
	print("Feb")
elif(a==3):print("Mar")
elif(a==4):print("Apr")
elif(a==5):print("May")
elif(a==6):print("Jun")
elif(a==7):print("Jul")
elif(a==8):print("Aug")
elif(a==9):print("Sep")
elif(a==10):print("Oct")
elif(a==11):print("Nov")
elif(a==12):print("Dec")
else:
	print("No Month Exists")
