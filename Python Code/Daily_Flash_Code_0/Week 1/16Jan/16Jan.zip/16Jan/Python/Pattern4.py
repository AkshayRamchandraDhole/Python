k=1

for x in range(4):
	for y in range(4):
		
		print(k,end=' ')
		k=k+1
	print(" ")
