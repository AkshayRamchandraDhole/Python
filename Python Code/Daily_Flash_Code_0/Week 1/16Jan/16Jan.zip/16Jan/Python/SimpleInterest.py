p=float(input("Enter A Principle Amount:-"))
n=float(input("Enter A Number of Year:-"))
r=(float(input("Enter A Rate of Interest in Percentage:-")))


SI=float(p*n*r/100)

print("Simple Interest:-{0}".format(SI))
