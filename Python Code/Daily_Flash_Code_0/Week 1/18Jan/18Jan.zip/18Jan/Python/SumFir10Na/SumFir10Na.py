sum=0
for i in range(1,11):
	sum=sum+i
print("The Sum of First 10 Natural Number is:-",sum)
