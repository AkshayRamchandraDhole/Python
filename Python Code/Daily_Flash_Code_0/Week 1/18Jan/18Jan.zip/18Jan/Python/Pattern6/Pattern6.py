for i in range(4):
	for j in range(4):
		print("0",end=' ')
	print()
