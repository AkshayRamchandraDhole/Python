for x in range(4):
	for y in range(4):
		y=y+1
		print(y*2,end=' ')
	print(" ")
