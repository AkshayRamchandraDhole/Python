ch=input("Enter A Character:-")
print("The ASCII Value of'"+ch+"'is",ord(ch))
