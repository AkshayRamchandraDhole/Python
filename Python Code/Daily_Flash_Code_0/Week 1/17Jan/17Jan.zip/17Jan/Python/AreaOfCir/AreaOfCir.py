r=int(input("Enter A Radius Of Circle:-"))

PI=3.14

area=PI*r*r

print("Area Of Circle:-{0}".format(area))
