for x in range(4):
	for y in range(4):
		print("1",end=' ')
	print(" ")
