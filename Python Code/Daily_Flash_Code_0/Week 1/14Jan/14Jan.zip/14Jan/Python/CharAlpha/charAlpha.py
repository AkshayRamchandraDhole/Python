ch=input("Enter a Character")

if ((ch >= 'a' and ch <= 'z') or (ch >= 'A' and ch <= 'Z')):
	print(ch,"is not Alphabet")
else:
	print(ch,"is Alphabet") 
