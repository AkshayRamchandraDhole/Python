ch=input("Enter a Character")
if(ch == 'a' or ch == 'A' or ch == 'e' or ch == 'E' or ch == 'i' or ch == 'I' or ch == 'o' or ch == 'O' or ch == 'u' or ch == 'U'):
	print(ch,"is a Vowel")
else:
	print(ch,"is not Vowel")
