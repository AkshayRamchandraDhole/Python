x,y,z=input("Enter a Number:-").split()

if((x >= y) and (x >= z)):
	print("X is Highest Among Three Number")
elif((y >= x) and (y >= z)):
	print("Y is Highest Among Three Number")
else:
	print("Z is Highest Among Three Number")
