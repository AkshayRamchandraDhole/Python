a = int(input("Enter a Number:-"))

if a % 2 == 0 :
	print("{0} is Even Number".format(a))
else :
	print("{0} Odd Number".format(a))
