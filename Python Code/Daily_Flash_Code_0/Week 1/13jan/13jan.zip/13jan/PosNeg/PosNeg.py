a=int(input("Enter a number"))

if a==0 :
	print("{0} is number equal to zero".format(a))
elif a > 0 :
	print("{0} is Positive Number".format(a))
else :
	print("{0} is Negative Number".format(a))\
