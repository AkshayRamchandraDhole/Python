x,y=input("Enter a two Number:-").split()
if x > y :
	print("{0}is greater among two number".format(x))
else:
	print("{0}is greater among two number".format(y))
