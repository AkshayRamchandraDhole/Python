s=input("Enter String:")
for i in s:
    if(i=='a' or i=='A' or i=='e' or i=='E' or i=='i' or i=='I' or i=='o' or i=='O' or i=='u' or i=='U'):
        print("Vowels in entered string:",i,end='\n')

