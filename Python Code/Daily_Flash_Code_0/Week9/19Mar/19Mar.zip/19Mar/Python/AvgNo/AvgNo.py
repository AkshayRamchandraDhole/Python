n=int(input("How Many Number Do u Want enter:"))
su=0
for i in range(n):
    n1=int(input("Enter Number:"))
    su=su+n1
print("Average Of Number is:",su/n)
