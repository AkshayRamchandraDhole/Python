import array as arr
list1=[1,2,3,4,5,6,7,8,9]
a=arr.array('i',list1)
for i in a:
    print(i,end=' ')
print()

