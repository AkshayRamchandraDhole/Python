import array as arr
list1=list()
n=input("Enter String:")
list1=n
ar=arr.array('u',list1)
for i in ar:
    print(i,end=' ')
