print("Enter Number 1")
print("Real Part:")
r1=int(input())
print("Imaginary Part:")
i1=int(input())
#a=r1+i1

print("Enter Number 2")
print("Real Part:")
r2=int(input())
print("Imaginary Part:")
i2=int(input())
#b=r2+i2

c=r1+r2
d=i1+i2

print("The Addition of",r1,"+i",i1,"&",r2,"+i",i2,"is:-",c,"+i",d)

