x,y=input().split()
x=int(x)
y=int(y)
print("Before Swap :a=",x,"&","b=",y)
x=x+y
y=x-y
x=x-y
print("After Swap: a=",x,"&","b=",y)

