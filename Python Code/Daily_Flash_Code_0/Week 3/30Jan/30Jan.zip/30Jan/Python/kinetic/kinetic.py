mass=int(input("Enter Mass:-"))
vel=int(input("Enter Velocity:-"))

KE=0.5 * mass * vel * vel\

print("Kinetic Energy of that object:-",KE)
