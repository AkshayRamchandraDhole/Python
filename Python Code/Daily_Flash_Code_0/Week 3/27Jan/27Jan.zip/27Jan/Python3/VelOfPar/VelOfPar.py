dis=int(input("Enter Distance in Meter:-"))
tim=int(input("Enter Time in Sec:-"))
sp=dis/tim
print("The velocity of a particle roaming in space is:-",sp,"m/s")
