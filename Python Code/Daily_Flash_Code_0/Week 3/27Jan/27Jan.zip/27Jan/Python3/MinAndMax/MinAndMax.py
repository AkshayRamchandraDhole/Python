x=int(input("Enter First Number:-"))
y=int(input("Enter Second Number:-"))
if(x < y):
	print("The Minimum Number Among",x,"&",y,"is:-",x)
elif(x > y):
	print("The Minimum Number Among",x,"&",y,"is:-",y)
