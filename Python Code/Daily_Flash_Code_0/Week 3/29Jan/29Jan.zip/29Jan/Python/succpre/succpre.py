no=int(input())
print("Second Predecessor:-",no-2)
print("Second Sucessor:-",no+2)
