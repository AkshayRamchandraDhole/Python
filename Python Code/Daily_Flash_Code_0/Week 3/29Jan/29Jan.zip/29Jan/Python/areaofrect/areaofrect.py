l,b=input().split()
l=int(l)
b=int(b)
print("Area O Ractangle is:-",l*b)
