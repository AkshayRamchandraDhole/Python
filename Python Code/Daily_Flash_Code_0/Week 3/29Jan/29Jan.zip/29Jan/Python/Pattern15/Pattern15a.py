x=4
for i in range(5):
	for  j in range(i):
		print(x-i+j,end=" ")
	print()
