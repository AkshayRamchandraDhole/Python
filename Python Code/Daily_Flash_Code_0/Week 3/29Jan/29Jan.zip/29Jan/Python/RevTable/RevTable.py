x=int(input())
for i in range(10,0,-1):
	print(x,"*",i,"=",x*i)
