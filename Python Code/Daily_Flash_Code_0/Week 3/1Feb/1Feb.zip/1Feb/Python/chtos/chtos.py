def cov():
	print("Enter A Hours:-")
	h=int(input())
	h=h*60*60
	print(h,"sec")
cov()

