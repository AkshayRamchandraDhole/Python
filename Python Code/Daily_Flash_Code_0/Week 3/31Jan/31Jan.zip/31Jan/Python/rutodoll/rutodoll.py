ru=float(input("Enter A Rupees:-"))
doll=float(ru // 71)
print("Into Dollar is:-",doll,"$")


