x=int(input())
y=1
print(y,end=' ')
for i in range(x):
	y=y+x
	print(y,end=' ')
print()
