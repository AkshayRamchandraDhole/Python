
for i in range(0,6):
	for j in range(4,i-1,-1):
		print(chr(i+65),end=' ')
	print()
