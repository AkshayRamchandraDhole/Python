x=int(input())
y=int(input())
fact=1
for i in range(x,y+1):
	fact=fact*i
	print("Factorial Of",i,"=",fact)
