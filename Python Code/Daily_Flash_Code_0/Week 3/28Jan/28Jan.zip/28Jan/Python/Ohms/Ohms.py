i=int(input("Enter Current:-"))
r=int(input("Enter Resistance:-"))
print("Volatge:-",i*r,"V")
