h=int(input("Enter Heigth of Triangle:"))
b=int(input("Enter Base of Triangle:"))
print("The Area Of Triangle is:",1/2*h*b)
