st=input("Enter String:")
print(st.lower())
