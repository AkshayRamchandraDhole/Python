st=input("Enter String:")
#print("Length of string is:",len(st))
a=0
for i in st:
    a+=1
print("Length of string is:",a)
