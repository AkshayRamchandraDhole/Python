a=int(input("Enter Area Of Triangle:"))
b=int(input("Enter Base of Triaangle:"))
print("Heigth Of that triangle is:",2*a/b)
