a=int(input("Enter Area Of Triangle:"))
h=int(input("Enter Height of Triangle:"))
print("The Base of Triangle:",2*a/h)
