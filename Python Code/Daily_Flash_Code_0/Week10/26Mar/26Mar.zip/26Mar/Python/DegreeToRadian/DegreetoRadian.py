de=int(input("Enter Degree:"))
pie=3.14
ra=de*pie/180
print("In Radian:",ra)
