st=input("Enter String:")

print(st[::-1])
