i=0 
list1=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
while i > -1:
    n=input("Enter Alphabet:")
    if(list1[i]!=n):
        break
    print(n)
    i+=1