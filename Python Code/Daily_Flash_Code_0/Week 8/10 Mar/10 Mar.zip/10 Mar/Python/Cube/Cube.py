
i=1 
while i > 0:
    n=int(input("Enter Number:"))
    if n < 0:
        break
    print("Cube Of Number is:",n*n*n)
    i+=1