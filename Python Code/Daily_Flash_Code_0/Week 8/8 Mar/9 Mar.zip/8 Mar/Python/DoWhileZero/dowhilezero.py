i=1
while i > 0:
    n=int(input("enter number:"))

    if n == 0:
        break
    print(n)