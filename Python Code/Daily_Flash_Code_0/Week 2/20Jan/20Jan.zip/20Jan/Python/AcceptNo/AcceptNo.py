no=int(input("Enter A Integer Value:-"))
print("Enter Value is:-",no)
