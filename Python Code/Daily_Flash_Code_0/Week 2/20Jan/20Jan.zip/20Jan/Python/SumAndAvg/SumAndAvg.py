sum=0
for i in range(10):
	i=int(input("Enter 10 Number:-"))
	sum=sum+i
print("Sum Of Number is:",sum)
print("Average Of Number is:-",sum//10)

