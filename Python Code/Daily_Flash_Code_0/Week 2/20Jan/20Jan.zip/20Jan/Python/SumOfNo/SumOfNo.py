no=int(input("Enter A Number:-"))
sum=0
for i in range(0,no+1):
	sum=sum+i
print("Sum Of Number is:-",sum)
