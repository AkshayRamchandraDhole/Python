no=int(input("Enter A Number:-"))
if(no % 2 == 0):
	print(str(no),"Number is Even")
else:
	print(str(no),"Number is Odd")
