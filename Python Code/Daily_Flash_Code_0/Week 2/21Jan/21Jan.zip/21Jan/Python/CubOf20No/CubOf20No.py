cube=0
for i in range(1,21):
	cube=i*i*i
	print("Cube of",i,":-",str(cube))
