no=int(input("Enter a Number who's table do you want:-"))
for i in range(1,11):
	print(no*i,end=' ')
print()
