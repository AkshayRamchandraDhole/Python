for i in range(5):
	for j in range(i):
		print("0",end=' ')
	print()
