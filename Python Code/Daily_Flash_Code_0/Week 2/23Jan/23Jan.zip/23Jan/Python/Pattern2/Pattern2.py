x=1
for i in range(5):
	for j in range(i):
		print(x,end=' ')
		x=x+1
	print()
