n1=int(input("Enter A First Number:-"))
n2=int(input("Enter Second Number:-"))

if(n1 > n2):
	print("The Maximum number among",n1,"&",n2,"is",n1)
else:
	print("The Maximum number among",n1,"&",n2,"is",n2)
