no=int(input("Enter A Number:-"))

for i in range(1,no+1):
	if(i % 2 == 0):
		print("Cube of",i,":",i*i*i,"and Square of",i,":",i*i)
