for i in range(6):
	for j in range(i):
		if(i % 2 == 0):
			print("A",end=' ')
		else:
			print("a",end=' ')
	print()
