a=int(input("Enter 1st Number:-"))
b=int(input("Enter 2nd Number:-"))
print("Before Swap:-",a,b)

tmp=a
a=b
b=tmp

print("After Swap:-",a,b)

