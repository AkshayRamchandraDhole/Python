no=int(input("Enter A Number:-"))
for i in range(1,no):
	if(i % 2 != 0):
		print("Cube of",str(i),":-",i*i*i,"Square is",str(i),":-",i*i)
