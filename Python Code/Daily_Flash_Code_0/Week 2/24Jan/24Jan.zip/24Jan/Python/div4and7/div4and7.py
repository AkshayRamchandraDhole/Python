for i in range(1,100):
	if(i % 4 == 0 and i % 7 == 0):
		print(i)
