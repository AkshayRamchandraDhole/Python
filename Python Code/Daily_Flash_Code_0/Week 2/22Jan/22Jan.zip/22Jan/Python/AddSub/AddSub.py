x=int(input("Enter First Number:-"))
y=int(input("Enter Second Number:-"))

z=x+y
print("Addition is:-",z)

if(y > x):
	p=y-x
	print("Substraction is:-",p)
else:
	print("Please Enter Second Number Greater Than First!!!")
