x=int(input("Enter A First Number:-"))
y=int(input("Enter A Second Number:-"))

a=x*x
b=y*y

c=x*x*x
d=y*y*y


z=c+d
print("Addition Of Their Cube is:-",z)

p=a-b
print("Substraction of Their Cube is:-",p)
