x=int(input("Enter First Number:-"))
y=int(input("Enter Second Number:-"))
z=x*y
print("Multiplication is:-",z)

if(x > y):

	p=x // y

	print("Division is:-",p)
else:
	print("Please Enter First Number Greater Than Second")
