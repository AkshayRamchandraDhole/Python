size=2
for i in range(size,-(size+1),-1):
    for j in range(abs(i),0,-1):
            print(" ",end=" ")
    for k in range(abs(i),3):
            print("0",end=" ")
    print()
