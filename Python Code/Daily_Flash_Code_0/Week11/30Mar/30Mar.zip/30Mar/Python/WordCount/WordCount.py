st=input("Enter String:")
x=len(st.split())
print("Enter String Contain",x,"words")
