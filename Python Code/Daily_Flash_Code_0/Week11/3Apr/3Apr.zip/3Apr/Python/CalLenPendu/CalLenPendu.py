fq=float(input("Frequency of pendulum in HZ:"))
fq**=2
pie=3.14
pie=4*pie**2
g=9.81
L=(pie*fq)/g
print("Length of that pendulum is:",round(L,2),"meters")
