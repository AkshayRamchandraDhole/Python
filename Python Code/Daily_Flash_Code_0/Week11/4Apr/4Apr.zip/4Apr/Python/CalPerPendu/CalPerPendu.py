f=float(input("Frequency of Pendulum in Hz:"))
P=1/f
print("Period of simple pendulum is:",round(P,2),"seconds")
