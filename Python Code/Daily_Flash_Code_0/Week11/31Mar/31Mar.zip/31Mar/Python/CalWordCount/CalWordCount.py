st=input("Enter String:")
s=0
for i in st:
    s+=1
print("The Length of entered string is:",s)

