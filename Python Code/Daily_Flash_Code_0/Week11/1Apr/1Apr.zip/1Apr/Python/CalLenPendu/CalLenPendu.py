T=float(input("Period of Pendulum in Seconds:"))
pie=3.14
pie=pie**2
g=9.81
z=T**2
Le=(4*pie*g)/z
print("Length of that Pendulum is:",round(Le,2),"meters")
