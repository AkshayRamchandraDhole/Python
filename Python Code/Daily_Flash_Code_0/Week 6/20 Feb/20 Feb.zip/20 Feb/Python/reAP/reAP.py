la=int(input("Enter Last Element:"))
cd=int(input("Enter Common Difference:"))
su=la
while(la>0):
	print(su,end=' ')
	su=la-cd
	la=su
print()
	

