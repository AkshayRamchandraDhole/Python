for x in range(4):
	for y in range(4):
		if(x<=y):
			print(x,y,end='\t')
		else:
			print(" ",end='\t')
	print()
