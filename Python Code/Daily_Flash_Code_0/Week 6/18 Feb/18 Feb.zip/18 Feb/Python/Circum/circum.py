r=int(input("Enter Radius:"))
pie=3.14
print("The Circumference of Circle with Radius",r,"is:",2*pie*r)
