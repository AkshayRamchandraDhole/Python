c=float(input("Enter Circumference:"))
r=c/6.28
r1=float(r)
print("Radius:",int(r1))
