n=int(input("Enter Number:"))
while n > 0:
	rem=n%10
	print(rem,end='')
	n=n//10
print()
