st=input("Enter String:")
a=st
rev=st[::-1]
if(rev==a):
    print("The entered string",rev,"is a palindrome string")
else:
    print("The string",rev,"is not palindrome")
