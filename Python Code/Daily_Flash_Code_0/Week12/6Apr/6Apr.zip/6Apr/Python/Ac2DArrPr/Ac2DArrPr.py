from array import array
list1=[[1,2],[3,4]]
for i in list1:
    for j in i:
        print(j,end='\t')
    print()


