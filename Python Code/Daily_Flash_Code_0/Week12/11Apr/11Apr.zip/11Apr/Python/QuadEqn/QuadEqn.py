a=int(input("Enter value of A:"))
b=int(input("Enter value of B:"))
c=int(input("Enter value of C:"))
d=(b**2)-(4*a*c)
x1=(-(b)+(d)**0.5)/2*a
x2=(-(b)-(d)**0.5)/2*a
print("Value of x1:",int(x1))
print("Value of x2:",int(x2))
