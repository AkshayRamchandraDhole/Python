st=input("Enter String:")
s1=" "
s=int(input("Enter starting index:"))
e=int(input("Enter ending index:"))
#for i in range(s,e):
s1=st[s:e+1]
print("Output string two after copying from one:",s1)
