st=input("Enter String:")
a=st
print("Copy string is:",a)
