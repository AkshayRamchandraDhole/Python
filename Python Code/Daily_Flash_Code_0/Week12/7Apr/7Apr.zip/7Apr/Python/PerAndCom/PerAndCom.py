import math as m
n=int(input("Enter N="))
r=int(input("Enter R="))
q=n-r
p=m.factorial(n)/m.factorial(r) * m.factorial(q)
print("To pick",r,"items from a set of",n,"there are",int(p),"possible combination")
