x1=int(input("X1:"))
y1=int(input("Y1:"))
x2=int(input("X2:"))
y2=int(input("Y2:"))

y=y2-y1
x=x2-x1
z=y//x

print("Slope of Line:",z)

