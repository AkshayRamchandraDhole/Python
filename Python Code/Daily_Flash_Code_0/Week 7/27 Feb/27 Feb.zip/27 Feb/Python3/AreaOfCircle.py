r=int(input("Enter Radius:"))
pie=3.14
print("Area:-",pie*r*r)
