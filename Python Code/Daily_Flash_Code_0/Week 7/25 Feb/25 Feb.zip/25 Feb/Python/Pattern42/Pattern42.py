for i in range(1,5):
	x=1
	y=4
	for j in range(1,5):
		if(i<=j):
			print(x,end=' ')
			x+=1
			z=x-1
		else:
			print(z,end=' ')
			z+=1	
		
	x-=1
	print()
