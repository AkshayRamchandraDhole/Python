def mid(a,b,c,d):
	x=a+b//2
	z=c+d//2
	print("Mid Point of Line AB:",x,z)
x1=int(input("Enter X1:"))
x2=int(input("Enter X2:"))
y1=int(input("Enter Y1:"))
y2=int(input("Enter Y2:"))
mid(x1,x2,y1,y2)
