import math as m
for i in range(200,600):
	x=m.sqrt(i)
	print(round(x,2),end='\t')
