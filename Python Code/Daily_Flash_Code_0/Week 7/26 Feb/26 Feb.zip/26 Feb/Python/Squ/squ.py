import math as m
for i in range(200,600):
	a=m.sqrt(i)
	print(round(a,2),end='\t')
