import math
n=int(input("ENter Number:"))
print("Square Root is:",math.sqrt(n))
