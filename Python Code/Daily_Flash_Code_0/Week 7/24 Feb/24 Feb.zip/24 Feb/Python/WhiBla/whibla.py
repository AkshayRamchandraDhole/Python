x="White-black"
y="black-white"
for i in range(3):
	for j in range(4):
		if(j%2==0):
			print(x,end=' ')
		else:
			print(y,end=' ')
	print()
