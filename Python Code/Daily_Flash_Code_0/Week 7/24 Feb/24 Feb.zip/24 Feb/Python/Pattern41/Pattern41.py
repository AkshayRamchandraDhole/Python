for i in range(5):
	for j in range(5):
		if(i<=j):
			print(i*j,end=' ')
		else:
			print(" ",end=' ')
	print()
	
