for i in range(1,5):
	for j in range(1,5):
		if(i==j):
			print("=",end=' ')
		else:
			print(j,end=' ')
	print()
