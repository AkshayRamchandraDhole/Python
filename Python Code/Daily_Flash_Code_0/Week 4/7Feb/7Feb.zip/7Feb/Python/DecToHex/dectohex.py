def dectohex(n):
	print("Hexademical Number:-",hex(n))
z=int(input("Enter Decimal Number:-"))
dectohex(z)
    
