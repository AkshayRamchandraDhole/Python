def ditokilo(x):
	x=x*1000
	print(x,"M")
n=int(input("Enter Distance into KM:-"))
ditokilo(n)
