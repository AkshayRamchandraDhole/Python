def wodivof2(x=10):
	for i in range(1,x+1):
		if(i % 2 != 0):
			print(i,end=' ')
wodivof2(100)
print()
	
