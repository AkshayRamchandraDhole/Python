n=97

for i in range(4):
	a=n
	for j in range(4,i,-1):
			print(chr(n),end=' ')
			n=n+1
			
	n=a+2
	print()
