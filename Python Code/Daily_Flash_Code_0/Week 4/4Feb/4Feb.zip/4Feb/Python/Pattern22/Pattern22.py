n=1
for i in range(1,5):
	for j in range(5,i,-1):
		print(n*7,end=' ')
		n=n+1	

	print()
