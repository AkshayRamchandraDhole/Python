def ftocen(x):
	y=x*30
	print("Equivalent distance for",x,"ft in cm is:-",y)
n=int(input("Enter Distance in feet:-"))
ftocen(n)
